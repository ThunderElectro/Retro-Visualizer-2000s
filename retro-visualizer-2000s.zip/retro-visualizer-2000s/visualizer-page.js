// Initialize visualizer page
if (typeof visualizer === 'undefined') {
    var visualizer = null;
}

document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('visualizer');
    visualizer = new RetroVisualizer(canvas);

    // Button handlers
    document.getElementById('startBtn').addEventListener('click', async () => {
        const success = await visualizer.start();
        if (success) {
            document.getElementById('startBtn').style.display = 'none';
            document.getElementById('stopBtn').style.display = 'flex';
        }
    });

    document.getElementById('stopBtn').addEventListener('click', () => {
        visualizer.stop();
        document.getElementById('startBtn').style.display = 'flex';
        document.getElementById('stopBtn').style.display = 'none';
    });

    document.getElementById('modeBtn').addEventListener('click', () => {
        visualizer.cycleMode();
    });

    // Settings panel
    const settingsPanel = document.getElementById('settingsPanel');
    const settingsBtn = document.getElementById('settingsBtn');
    const closeSettings = document.getElementById('closeSettings');

    settingsBtn.addEventListener('click', () => {
        settingsPanel.classList.add('active');
    });

    closeSettings.addEventListener('click', () => {
        settingsPanel.classList.remove('active');
    });

    // Settings controls
    document.getElementById('colorScheme').addEventListener('change', (e) => {
        visualizer.updateSettings({ colorScheme: e.target.value });
    });

    document.getElementById('sensitivity').addEventListener('input', (e) => {
        visualizer.updateSettings({ sensitivity: parseInt(e.target.value) });
        e.target.nextElementSibling.textContent = e.target.value;
    });

    document.getElementById('smoothing').addEventListener('input', (e) => {
        visualizer.updateSettings({ smoothing: parseInt(e.target.value) });
        e.target.nextElementSibling.textContent = e.target.value + '%';
    });

    document.getElementById('barCount').addEventListener('input', (e) => {
        visualizer.updateSettings({ barCount: parseInt(e.target.value) });
        e.target.nextElementSibling.textContent = e.target.value;
    });

    document.getElementById('mirrorMode').addEventListener('change', (e) => {
        visualizer.updateSettings({ mirrorMode: e.target.checked });
    });

    document.getElementById('glowEffect').addEventListener('change', (e) => {
        visualizer.updateSettings({ glowEffect: e.target.checked });
    });

    document.getElementById('resetSettings').addEventListener('click', () => {
        visualizer.updateSettings({
            colorScheme: 'neon',
            sensitivity: 5,
            smoothing: 80,
            barCount: 64,
            mirrorMode: false,
            glowEffect: true
        });

        // Update UI
        document.getElementById('colorScheme').value = 'neon';
        document.getElementById('sensitivity').value = 5;
        document.getElementById('sensitivity').nextElementSibling.textContent = '5';
        document.getElementById('smoothing').value = 80;
        document.getElementById('smoothing').nextElementSibling.textContent = '80%';
        document.getElementById('barCount').value = 64;
        document.getElementById('barCount').nextElementSibling.textContent = '64';
        document.getElementById('mirrorMode').checked = false;
        document.getElementById('glowEffect').checked = true;
    });
});

// Helper functions for visualizer
function updateStatus(text, className) {
    const statusText = document.getElementById('statusText');
    statusText.textContent = text;
    statusText.className = 'value ' + className;
}

function updateMode(mode) {
    document.getElementById('currentMode').textContent = mode;
}
