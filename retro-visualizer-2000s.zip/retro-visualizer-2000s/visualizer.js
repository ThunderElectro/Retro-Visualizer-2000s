// Retro Visualizer 2000
class RetroVisualizer {
    constructor(canvas) {
        this.canvas = canvas;
        this.ctx = canvas.getContext('2d', { willReadFrequently: true });

        this.isRunning = false;
        this.audioContext = null;
        this.analyser = null;
        this.dataArray = null;
        this.stream = null;

        this.currentMode = 0;
        this.modes = ['spectrum', 'waveform', 'vhs', 'oscilloscope', 'carradio', 'vfd', 'heartrate', 'dualwave', 'particle', 'space', 'speaker', 'neonwaves', 'vinyl', 'synth', 'radial2', 'bars', 'scope', 'macos', 'crt', 'stocks', 'waves'];

        // Settings
        this.settings = {
            colorScheme: 'neon',
            sensitivity: 5,
            smoothing: 80,
            barCount: 64,
            mirrorMode: false,
            glowEffect: true
        };

        this.colorSchemes = {
            neon: ['#00ffff', '#ff00ff', '#ffff00', '#00ff00'],
            plasma: ['#ff0080', '#8000ff', '#0080ff', '#ff8000'],
            matrix: ['#00ff00', '#00aa00', '#008800', '#00ff00'],
            sunset: ['#ff6b35', '#f7931e', '#fdc830', '#f37335'],
            ocean: ['#00d4ff', '#0099ff', '#0066ff', '#0033ff'],
            fire: ['#ff0000', '#ff6600', '#ffcc00', '#00ffff']
        };

        this.vhsOffset = 0;
        this.vhsGlitchTimer = 0;

        this.resize();
        window.addEventListener('resize', () => this.resize());

        this.loadSettings();
    }

    resize() {
        const rect = this.canvas.getBoundingClientRect();
        this.canvas.width = rect.width;
        this.canvas.height = rect.height;
    }

    async start() {
        try {
            updateStatus('CONNECTING', 'active');

            const streamId = await new Promise((resolve, reject) => {
                chrome.tabCapture.capture({ audio: true, video: false }, (stream) => {
                    if (chrome.runtime.lastError) {
                        reject(chrome.runtime.lastError);
                        return;
                    }
                    if (!stream) {
                        reject(new Error('No stream'));
                        return;
                    }
                    resolve(stream);
                });
            });

            this.stream = streamId;
            this.audioContext = new AudioContext();
            const source = this.audioContext.createMediaStreamSource(streamId);

            this.analyser = this.audioContext.createAnalyser();
            this.analyser.fftSize = 2048;
            this.analyser.smoothingTimeConstant = this.settings.smoothing / 100;

            source.connect(this.analyser);
            source.connect(this.audioContext.destination); // Play audio

            const bufferLength = this.analyser.frequencyBinCount;
            this.dataArray = new Uint8Array(bufferLength);

            this.isRunning = true;
            updateStatus('ACTIVE', 'active');

            this.animate();

            return true;
        } catch (error) {
            console.error('Error:', error);
            updateStatus('ERROR', 'error');
            return false;
        }
    }

    stop() {
        this.isRunning = false;

        if (this.stream) {
            this.stream.getTracks().forEach(track => track.stop());
            this.stream = null;
        }

        if (this.audioContext) {
            this.audioContext.close();
            this.audioContext = null;
        }

        updateStatus('READY', '');
    }

    animate() {
        if (!this.isRunning) return;

        this.analyser.getByteFrequencyData(this.dataArray);

        const mode = this.modes[this.currentMode];

        // Clear with mode-specific background
        if (mode === 'vhs') {
            this.drawVHSBackground();
        } else {
            this.ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
            this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
        }

        // Draw based on current mode
        switch (mode) {
            case 'spectrum':
                this.drawSpectrum();
                break;
            case 'waveform':
                this.drawWaveform();
                break;
            case 'vhs':
                this.drawVHS();
                break;
            case 'oscilloscope':
                this.drawOscilloscope();
                break;
            case 'carradio':
                this.drawCarRadio();
                break;
            case 'vfd':
                this.drawVFD();
                break;
            case 'heartrate':
                this.drawHeartRate();
                break;
            case 'dualwave':
                this.drawDualWave();
                break;
            case 'particle':
                this.drawParticle();
                break;
            case 'space':
                this.drawSpace();
                break;
            case 'speaker':
                this.drawSpeaker();
                break;
            case 'neonwaves':
                this.drawNeonWaves();
                break;
            case 'vinyl':
                this.drawVinyl();
                break;
            case 'synth':
                this.drawSynth();
                break;
            case 'radial2':
                this.drawRadial2();
                break;
            case 'bars':
                this.drawBars();
                break;
            case 'scope':
                this.drawScope();
                break;
            case 'macos':
                this.drawMacOS();
                break;
            case 'crt':
                this.drawCRT();
                break;
            case 'stocks':
                this.drawStocks();
                break;
            case 'waves':
                this.drawWaves();
                break;
        }

        requestAnimationFrame(() => this.animate());
    }

    drawSpectrum() {
        const barCount = this.settings.barCount;
        const barWidth = this.canvas.width / barCount;
        const colors = this.colorSchemes[this.settings.colorScheme];

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * this.canvas.height * (this.settings.sensitivity / 5);

            const colorIndex = Math.floor((i / barCount) * colors.length);
            const color = colors[colorIndex % colors.length];

            const x = i * barWidth;
            const y = this.canvas.height - barHeight;

            // Draw bar
            this.ctx.fillStyle = color;
            this.ctx.fillRect(x, y, barWidth - 2, barHeight);

            // Glow effect
            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 20;
                this.ctx.shadowColor = color;
                this.ctx.fillRect(x, y, barWidth - 2, barHeight);
                this.ctx.shadowBlur = 0;
            }

            // Mirror mode
            if (this.settings.mirrorMode) {
                this.ctx.save();
                this.ctx.globalAlpha = 0.5;
                this.ctx.scale(1, -1);
                this.ctx.fillRect(x, -this.canvas.height + y, barWidth - 2, barHeight);
                this.ctx.restore();
            }
        }
    }

    drawWaveform() {
        this.analyser.getByteTimeDomainData(this.dataArray);

        const colors = this.colorSchemes[this.settings.colorScheme];
        const sliceWidth = this.canvas.width / this.dataArray.length;

        this.ctx.lineWidth = 3;
        this.ctx.strokeStyle = colors[0];

        if (this.settings.glowEffect) {
            this.ctx.shadowBlur = 15;
            this.ctx.shadowColor = colors[0];
        }

        this.ctx.beginPath();

        for (let i = 0; i < this.dataArray.length; i++) {
            const v = this.dataArray[i] / 128.0;
            const y = (v * this.canvas.height) / 2;
            const x = i * sliceWidth;

            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }

        this.ctx.stroke();
        this.ctx.shadowBlur = 0;
    }

    drawCircular() {
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;
        const radius = Math.min(centerX, centerY) * 0.6;
        const colors = this.colorSchemes[this.settings.colorScheme];

        const barCount = this.settings.barCount;
        const angleStep = (Math.PI * 2) / barCount;

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * radius * (this.settings.sensitivity / 5);

            const angle = i * angleStep - Math.PI / 2;
            const x1 = centerX + Math.cos(angle) * radius;
            const y1 = centerY + Math.sin(angle) * radius;
            const x2 = centerX + Math.cos(angle) * (radius + barHeight);
            const y2 = centerY + Math.sin(angle) * (radius + barHeight);

            const colorIndex = Math.floor((i / barCount) * colors.length);
            const color = colors[colorIndex % colors.length];

            this.ctx.strokeStyle = color;
            this.ctx.lineWidth = 4;

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 15;
                this.ctx.shadowColor = color;
            }

            this.ctx.beginPath();
            this.ctx.moveTo(x1, y1);
            this.ctx.lineTo(x2, y2);
            this.ctx.stroke();
        }

        this.ctx.shadowBlur = 0;
    }

    drawVHSBackground() {
        // VHS static background
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Add VHS noise
        const imageData = this.ctx.getImageData(0, 0, this.canvas.width, this.canvas.height);
        const data = imageData.data;

        for (let i = 0; i < data.length; i += 4) {
            if (Math.random() < 0.02) {
                const noise = Math.random() * 50;
                data[i] = noise;
                data[i + 1] = noise;
                data[i + 2] = noise;
            }
        }

        this.ctx.putImageData(imageData, 0, 0);
    }

    drawVHS() {
        const colors = this.colorSchemes[this.settings.colorScheme];
        const barCount = this.settings.barCount;
        const barWidth = this.canvas.width / barCount;

        // VHS glitch effect
        this.vhsGlitchTimer++;
        if (this.vhsGlitchTimer > 60 && Math.random() < 0.1) {
            this.vhsOffset = (Math.random() - 0.5) * 20;
            this.vhsGlitchTimer = 0;
        } else {
            this.vhsOffset *= 0.9;
        }

        // Draw spectrum with VHS distortion
        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * this.canvas.height * (this.settings.sensitivity / 5);

            const colorIndex = Math.floor((i / barCount) * colors.length);
            const color = colors[colorIndex % colors.length];

            const x = i * barWidth + this.vhsOffset;
            const y = this.canvas.height - barHeight;

            // RGB split effect
            this.ctx.globalAlpha = 0.7;

            // Red channel
            this.ctx.fillStyle = '#ff0000';
            this.ctx.fillRect(x - 2, y, barWidth - 2, barHeight);

            // Green channel
            this.ctx.fillStyle = '#00ff00';
            this.ctx.fillRect(x, y, barWidth - 2, barHeight);

            // Blue channel
            this.ctx.fillStyle = '#0000ff';
            this.ctx.fillRect(x + 2, y, barWidth - 2, barHeight);

            this.ctx.globalAlpha = 1.0;
        }

        // Add horizontal scan lines
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        this.ctx.lineWidth = 1;
        for (let y = 0; y < this.canvas.height; y += 4) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, y);
            this.ctx.lineTo(this.canvas.width, y);
            this.ctx.stroke();
        }

        // VHS tracking distortion
        if (Math.random() < 0.05) {
            const distortY = Math.random() * this.canvas.height;
            const distortHeight = Math.random() * 30;
            this.ctx.fillStyle = 'rgba(255, 255, 255, 0.1)';
            this.ctx.fillRect(0, distortY, this.canvas.width, distortHeight);
        }
    }

    drawOscilloscope() {
        this.analyser.getByteTimeDomainData(this.dataArray);

        const colors = this.colorSchemes[this.settings.colorScheme];
        const centerY = this.canvas.height / 2;

        // Draw grid
        this.ctx.strokeStyle = 'rgba(0, 255, 0, 0.2)';
        this.ctx.lineWidth = 1;

        // Horizontal lines
        for (let y = 0; y < this.canvas.height; y += 30) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, y);
            this.ctx.lineTo(this.canvas.width, y);
            this.ctx.stroke();
        }

        // Vertical lines
        for (let x = 0; x < this.canvas.width; x += 30) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, 0);
            this.ctx.lineTo(x, this.canvas.height);
            this.ctx.stroke();
        }

        // Draw waveform
        const sliceWidth = this.canvas.width / this.dataArray.length;

        this.ctx.lineWidth = 3;
        this.ctx.strokeStyle = colors[0];

        if (this.settings.glowEffect) {
            this.ctx.shadowBlur = 20;
            this.ctx.shadowColor = colors[0];
        }

        this.ctx.beginPath();

        for (let i = 0; i < this.dataArray.length; i++) {
            const v = (this.dataArray[i] - 128) / 128.0;
            const y = centerY + (v * centerY * (this.settings.sensitivity / 5));
            const x = i * sliceWidth;

            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }

        this.ctx.stroke();
        this.ctx.shadowBlur = 0;
    }

    drawBars3D() {
        const barCount = this.settings.barCount;
        const barWidth = this.canvas.width / barCount;
        const colors = this.colorSchemes[this.settings.colorScheme];
        const perspective = 0.7;

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * this.canvas.height * (this.settings.sensitivity / 5);

            const colorIndex = Math.floor((i / barCount) * colors.length);
            const color = colors[colorIndex % colors.length];

            const x = i * barWidth;
            const y = this.canvas.height - barHeight;

            // 3D effect - draw sides
            const depth = 8;

            // Top face
            this.ctx.fillStyle = this.lightenColor(color, 30);
            this.ctx.beginPath();
            this.ctx.moveTo(x, y);
            this.ctx.lineTo(x + barWidth - 2, y);
            this.ctx.lineTo(x + barWidth - 2 + depth, y - depth);
            this.ctx.lineTo(x + depth, y - depth);
            this.ctx.closePath();
            this.ctx.fill();

            // Right face
            this.ctx.fillStyle = this.darkenColor(color, 20);
            this.ctx.beginPath();
            this.ctx.moveTo(x + barWidth - 2, y);
            this.ctx.lineTo(x + barWidth - 2, this.canvas.height);
            this.ctx.lineTo(x + barWidth - 2 + depth, this.canvas.height - depth);
            this.ctx.lineTo(x + barWidth - 2 + depth, y - depth);
            this.ctx.closePath();
            this.ctx.fill();

            // Front face
            this.ctx.fillStyle = color;
            this.ctx.fillRect(x, y, barWidth - 2, barHeight);

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 15;
                this.ctx.shadowColor = color;
                this.ctx.fillRect(x, y, barWidth - 2, barHeight);
                this.ctx.shadowBlur = 0;
            }
        }
    }

    lightenColor(color, percent) {
        const num = parseInt(color.replace('#', ''), 16);
        const amt = Math.round(2.55 * percent);
        const R = Math.min(255, (num >> 16) + amt);
        const G = Math.min(255, ((num >> 8) & 0x00FF) + amt);
        const B = Math.min(255, (num & 0x0000FF) + amt);
        return '#' + (0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1);
    }

    darkenColor(color, percent) {
        const num = parseInt(color.replace('#', ''), 16);
        const amt = Math.round(2.55 * percent);
        const R = Math.max(0, (num >> 16) - amt);
        const G = Math.max(0, ((num >> 8) & 0x00FF) - amt);
        const B = Math.max(0, (num & 0x0000FF) - amt);
        return '#' + (0x1000000 + R * 0x10000 + G * 0x100 + B).toString(16).slice(1);
    }

    cycleMode() {
        this.currentMode = (this.currentMode + 1) % this.modes.length;
        updateMode(this.modes[this.currentMode].toUpperCase());
    }

    updateSettings(settings) {
        this.settings = { ...this.settings, ...settings };
        if (this.analyser) {
            this.analyser.smoothingTimeConstant = this.settings.smoothing / 100;
        }
        this.saveSettings();
    }

    saveSettings() {
        chrome.storage.sync.set({ retroSettings: this.settings });
    }

    async loadSettings() {
        try {
            const result = await chrome.storage.sync.get('retroSettings');
            if (result.retroSettings) {
                this.settings = { ...this.settings, ...result.retroSettings };
            }
        } catch (error) {
            console.error('Error loading settings:', error);
        }
    }

    drawCarRadio() {
        // Classic car radio/stereo visualizer (improved design)
        const colors = this.colorSchemes[this.settings.colorScheme];
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Draw radio faceplate background
        const faceWidth = Math.min(this.canvas.width * 0.7, 700);
        const faceHeight = Math.min(this.canvas.height * 0.4, 200);
        const faceX = centerX - faceWidth / 2;
        const faceY = centerY - faceHeight / 2;

        // Metallic faceplate with better gradient
        const gradient = this.ctx.createLinearGradient(faceX, faceY, faceX, faceY + faceHeight);
        gradient.addColorStop(0, '#1a1a1a');
        gradient.addColorStop(0.5, '#0a0a0a');
        gradient.addColorStop(1, '#1a1a1a');
        this.ctx.fillStyle = gradient;
        this.ctx.fillRect(faceX, faceY, faceWidth, faceHeight);

        // Border
        this.ctx.strokeStyle = '#333';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(faceX, faceY, faceWidth, faceHeight);

        // LCD Display area (larger and centered)
        const lcdWidth = faceWidth * 0.85;
        const lcdHeight = faceHeight * 0.6;
        const lcdX = faceX + (faceWidth - lcdWidth) / 2;
        const lcdY = faceY + 15;

        // LCD background (amber/orange tint for vintage look)
        this.ctx.fillStyle = '#1a0f00';
        this.ctx.fillRect(lcdX, lcdY, lcdWidth, lcdHeight);

        // LCD border
        this.ctx.strokeStyle = '#ff8800';
        this.ctx.lineWidth = 1;
        this.ctx.strokeRect(lcdX, lcdY, lcdWidth, lcdHeight);

        // Draw spectrum in LCD
        const barCount = 24;
        const barWidth = (lcdWidth - 20) / barCount;
        const barMaxHeight = lcdHeight - 20;

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * barMaxHeight * (this.settings.sensitivity / 5);

            const x = lcdX + 10 + i * barWidth;
            const y = lcdY + lcdHeight - 10 - barHeight;

            // Orange LCD bars
            this.ctx.fillStyle = '#ff8800';
            this.ctx.fillRect(x, y, barWidth - 2, barHeight);

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 8;
                this.ctx.shadowColor = '#ff8800';
                this.ctx.fillRect(x, y, barWidth - 2, barHeight);
                this.ctx.shadowBlur = 0;
            }
        }

        // Simple control buttons at bottom
        const buttonY = faceY + lcdHeight + 25;
        const buttonWidth = 40;
        const buttonHeight = 20;
        const buttonSpacing = 15;
        const totalButtonWidth = (buttonWidth * 5) + (buttonSpacing * 4);
        const buttonStartX = centerX - totalButtonWidth / 2;

        for (let i = 0; i < 5; i++) {
            const buttonX = buttonStartX + i * (buttonWidth + buttonSpacing);

            // Button
            this.ctx.fillStyle = '#222';
            this.ctx.fillRect(buttonX, buttonY, buttonWidth, buttonHeight);
            this.ctx.strokeStyle = '#444';
            this.ctx.lineWidth = 1;
            this.ctx.strokeRect(buttonX, buttonY, buttonWidth, buttonHeight);
        }
    }

    drawVFD() {
        // Vacuum Fluorescent Display visualizer (simplified)
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // VFD background (dark with slight blue tint)
        this.ctx.fillStyle = '#0a0a15';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // VFD panel
        const panelWidth = Math.min(this.canvas.width * 0.9, 900);
        const panelHeight = Math.min(this.canvas.height * 0.5, 300);
        const panelX = centerX - panelWidth / 2;
        const panelY = centerY - panelHeight / 2;

        // Panel background
        this.ctx.fillStyle = '#000510';
        this.ctx.fillRect(panelX, panelY, panelWidth, panelHeight);

        // Panel border with VFD glow
        this.ctx.strokeStyle = '#00ffcc';
        this.ctx.lineWidth = 2;
        this.ctx.shadowBlur = 15;
        this.ctx.shadowColor = '#00ffcc';
        this.ctx.strokeRect(panelX, panelY, panelWidth, panelHeight);
        this.ctx.shadowBlur = 0;

        // Spectrum analyzer area
        const spectrumY = panelY + 20;
        const spectrumHeight = panelHeight - 40;
        const barCount = 32;
        const barWidth = (panelWidth - 40) / barCount;

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * spectrumHeight * (this.settings.sensitivity / 5);

            const x = panelX + 20 + i * barWidth;
            const y = spectrumY + spectrumHeight - barHeight;

            // VFD characteristic blue-green color
            const vfdColor = '#00ffcc';

            // Draw bar with segmented look
            const segments = Math.floor(barHeight / 8);
            for (let seg = 0; seg < segments; seg++) {
                const segY = spectrumY + spectrumHeight - (seg * 8) - 6;

                this.ctx.fillStyle = vfdColor;
                this.ctx.fillRect(x, segY, barWidth - 3, 5);

                if (this.settings.glowEffect) {
                    this.ctx.shadowBlur = 8;
                    this.ctx.shadowColor = vfdColor;
                    this.ctx.fillRect(x, segY, barWidth - 3, 5);
                    this.ctx.shadowBlur = 0;
                }
            }
        }
    }

    drawHeartRate() {
        // Heart Rate Monitor / ECG visualizer
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Medical monitor background (dark green tint)
        this.ctx.fillStyle = '#0a0f0a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Monitor panel
        const panelWidth = Math.min(this.canvas.width * 0.9, 900);
        const panelHeight = Math.min(this.canvas.height * 0.6, 400);
        const panelX = centerX - panelWidth / 2;
        const panelY = centerY - panelHeight / 2;

        // Panel background
        this.ctx.fillStyle = '#000';
        this.ctx.fillRect(panelX, panelY, panelWidth, panelHeight);

        // Panel border
        this.ctx.strokeStyle = '#00ff00';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(panelX, panelY, panelWidth, panelHeight);

        // Grid lines (like ECG paper)
        this.ctx.strokeStyle = 'rgba(0, 255, 0, 0.1)';
        this.ctx.lineWidth = 1;
        for (let x = panelX; x < panelX + panelWidth; x += 20) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, panelY);
            this.ctx.lineTo(x, panelY + panelHeight);
            this.ctx.stroke();
        }
        for (let y = panelY; y < panelY + panelHeight; y += 20) {
            this.ctx.beginPath();
            this.ctx.moveTo(panelX, y);
            this.ctx.lineTo(panelX + panelWidth, y);
            this.ctx.stroke();
        }

        // Calculate heart rate from audio
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const bpm = Math.floor(60 + (average / 255) * 140); // 60-200 BPM

        // BPM display
        this.ctx.font = 'bold 48px "Courier New"';
        this.ctx.fillStyle = '#00ff00';
        this.ctx.textAlign = 'right';
        this.ctx.shadowBlur = 15;
        this.ctx.shadowColor = '#00ff00';
        this.ctx.fillText(bpm, panelX + panelWidth - 20, panelY + 60);
        this.ctx.font = 'bold 16px "Courier New"';
        this.ctx.fillText('BPM', panelX + panelWidth - 20, panelY + 80);
        this.ctx.shadowBlur = 0;

        // ECG waveform area
        const waveY = panelY + 100;
        const waveHeight = panelHeight - 120;
        const waveWidth = panelWidth - 40;

        // Draw ECG-style waveform
        this.analyser.getByteTimeDomainData(this.dataArray);

        this.ctx.strokeStyle = '#00ff00';
        this.ctx.lineWidth = 2;
        this.ctx.shadowBlur = 10;
        this.ctx.shadowColor = '#00ff00';

        this.ctx.beginPath();
        const sliceWidth = waveWidth / this.dataArray.length;

        for (let i = 0; i < this.dataArray.length; i++) {
            const v = (this.dataArray[i] - 128) / 128.0;
            const y = waveY + waveHeight / 2 + (v * waveHeight / 2 * (this.settings.sensitivity / 5));
            const x = panelX + 20 + i * sliceWidth;

            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }

        this.ctx.stroke();
        this.ctx.shadowBlur = 0;

        // Status indicators
        this.ctx.font = 'bold 14px "Courier New"';
        this.ctx.fillStyle = '#00ff00';
        this.ctx.textAlign = 'left';
        this.ctx.fillText('MONITORING', panelX + 20, panelY + 30);

        // Pulse indicator (blinks with audio)
        if (average > 100) {
            this.ctx.beginPath();
            this.ctx.arc(panelX + 20, panelY + 50, 8, 0, Math.PI * 2);
            this.ctx.fillStyle = '#ff0000';
            this.ctx.fill();
            this.ctx.shadowBlur = 15;
            this.ctx.shadowColor = '#ff0000';
            this.ctx.fill();
            this.ctx.shadowBlur = 0;
        }
    }

    drawDualWave() {
        // Dual mirrored waveforms
        const colors = this.colorSchemes[this.settings.colorScheme];
        const centerY = this.canvas.height / 2;

        // Get time domain data
        this.analyser.getByteTimeDomainData(this.dataArray);

        // Top waveform
        this.ctx.strokeStyle = colors[0];
        this.ctx.lineWidth = 3;
        if (this.settings.glowEffect) {
            this.ctx.shadowBlur = 15;
            this.ctx.shadowColor = colors[0];
        }

        this.ctx.beginPath();
        const sliceWidth = this.canvas.width / this.dataArray.length;

        for (let i = 0; i < this.dataArray.length; i++) {
            const v = (this.dataArray[i] - 128) / 128.0;
            const y = centerY - 50 - (v * (centerY - 100) * (this.settings.sensitivity / 5));
            const x = i * sliceWidth;

            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }
        this.ctx.stroke();

        // Bottom waveform (mirrored)
        this.ctx.strokeStyle = colors[1];
        if (this.settings.glowEffect) {
            this.ctx.shadowColor = colors[1];
        }

        this.ctx.beginPath();
        for (let i = 0; i < this.dataArray.length; i++) {
            const v = (this.dataArray[i] - 128) / 128.0;
            const y = centerY + 50 + (v * (centerY - 100) * (this.settings.sensitivity / 5));
            const x = i * sliceWidth;

            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }
        this.ctx.stroke();
        this.ctx.shadowBlur = 0;

        // Center line
        this.ctx.strokeStyle = colors[2];
        this.ctx.lineWidth = 1;
        this.ctx.beginPath();
        this.ctx.moveTo(0, centerY);
        this.ctx.lineTo(this.canvas.width, centerY);
        this.ctx.stroke();
    }

    drawPlasma() {
        // Flowing plasma effect
        const colors = this.colorSchemes[this.settings.colorScheme];
        const time = Date.now() * 0.001;

        // Create plasma effect with audio reactivity
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const intensity = (average / 255) * (this.settings.sensitivity / 5);

        for (let y = 0; y < this.canvas.height; y += 4) {
            for (let x = 0; x < this.canvas.width; x += 4) {
                // Plasma formula
                const value = Math.sin(x / 50 + time) +
                    Math.sin(y / 50 + time * 1.5) +
                    Math.sin((x + y) / 50 + time * 2) +
                    Math.sin(Math.sqrt(x * x + y * y) / 50 + time * 3);

                const colorIndex = Math.floor(((value + 4) / 8 + intensity) * colors.length) % colors.length;
                this.ctx.fillStyle = colors[colorIndex];
                this.ctx.fillRect(x, y, 4, 4);
            }
        }
    }

    drawTunnel() {
        // 3D tunnel effect
        const colors = this.colorSchemes[this.settings.colorScheme];
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;
        const time = Date.now() * 0.001;

        // Audio reactivity
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const intensity = (average / 255) * (this.settings.sensitivity / 5);

        // Draw concentric circles creating tunnel effect
        const maxRadius = Math.sqrt(centerX * centerX + centerY * centerY);
        const numRings = 20;

        for (let i = 0; i < numRings; i++) {
            const radius = maxRadius * (1 - i / numRings) + intensity * 50;
            const colorIndex = (i + Math.floor(time * 5)) % colors.length;

            this.ctx.strokeStyle = colors[colorIndex];
            this.ctx.lineWidth = 10;

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 20;
                this.ctx.shadowColor = colors[colorIndex];
            }

            this.ctx.beginPath();
            this.ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
            this.ctx.stroke();
        }
        this.ctx.shadowBlur = 0;
    }

    drawParticle() {
        // Particle system visualizer
        const colors = this.colorSchemes[this.settings.colorScheme];
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Initialize particles if needed
        if (!this.particles) {
            this.particles = [];
            for (let i = 0; i < 100; i++) {
                this.particles.push({
                    x: centerX,
                    y: centerY,
                    vx: (Math.random() - 0.5) * 10,
                    vy: (Math.random() - 0.5) * 10,
                    life: 1.0,
                    color: colors[Math.floor(Math.random() * colors.length)]
                });
            }
        }

        // Fade background
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Update and draw particles based on audio
        const barCount = 32;
        for (let i = 0; i < this.particles.length; i++) {
            const particle = this.particles[i];
            const dataIndex = Math.floor((i / this.particles.length) * barCount);
            const audioValue = this.dataArray[Math.floor(dataIndex * this.dataArray.length / barCount)];
            const force = (audioValue / 255) * (this.settings.sensitivity / 5);

            // Update position
            particle.x += particle.vx * force;
            particle.y += particle.vy * force;
            particle.life -= 0.01;

            // Reset if dead or out of bounds
            if (particle.life <= 0 || particle.x < 0 || particle.x > this.canvas.width ||
                particle.y < 0 || particle.y > this.canvas.height) {
                particle.x = centerX;
                particle.y = centerY;
                particle.vx = (Math.random() - 0.5) * 10;
                particle.vy = (Math.random() - 0.5) * 10;
                particle.life = 1.0;
                particle.color = colors[Math.floor(Math.random() * colors.length)];
            }

            // Draw particle
            this.ctx.fillStyle = particle.color;
            this.ctx.globalAlpha = particle.life;
            this.ctx.beginPath();
            this.ctx.arc(particle.x, particle.y, 3, 0, Math.PI * 2);
            this.ctx.fill();

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 10;
                this.ctx.shadowColor = particle.color;
                this.ctx.fill();
                this.ctx.shadowBlur = 0;
            }
        }
        this.ctx.globalAlpha = 1.0;
    }

    drawSpace() {
        // Space/starfield visualizer with explosion effect
        const colors = this.colorSchemes[this.settings.colorScheme];

        // Initialize stars if needed
        if (!this.stars) {
            this.stars = [];
            for (let i = 0; i < 200; i++) {
                this.stars.push({
                    x: Math.random() * this.canvas.width,
                    y: Math.random() * this.canvas.height,
                    z: Math.random() * this.canvas.width,
                    color: colors[Math.floor(Math.random() * colors.length)],
                    explosionVx: 0,
                    explosionVy: 0
                });
            }
        }

        // Black space background
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Audio reactivity
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const normalizedVolume = average / 255;
        const speed = 1 + normalizedVolume * 5 * (this.settings.sensitivity / 5);

        // Explosion threshold - when volume is loud
        const explosionThreshold = 0.7;
        const isLoud = normalizedVolume > explosionThreshold;

        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Update and draw stars
        for (let i = 0; i < this.stars.length; i++) {
            const star = this.stars[i];

            if (isLoud) {
                // EXPLOSION MODE - stars burst outward from center
                if (star.explosionVx === 0 && star.explosionVy === 0) {
                    // Initialize explosion velocity
                    const angle = Math.random() * Math.PI * 2;
                    const explosionSpeed = 5 + Math.random() * 10;
                    star.explosionVx = Math.cos(angle) * explosionSpeed;
                    star.explosionVy = Math.sin(angle) * explosionSpeed;
                }

                // Move star outward
                star.x += star.explosionVx;
                star.y += star.explosionVy;

                // Reset if out of bounds
                if (star.x < 0 || star.x > this.canvas.width ||
                    star.y < 0 || star.y > this.canvas.height) {
                    star.x = centerX;
                    star.y = centerY;
                    star.z = this.canvas.width;
                    star.explosionVx = 0;
                    star.explosionVy = 0;
                    star.color = colors[Math.floor(Math.random() * colors.length)];
                }

                // Draw exploding star
                const size = 3 + normalizedVolume * 5;
                this.ctx.fillStyle = star.color;
                this.ctx.beginPath();
                this.ctx.arc(star.x, star.y, size, 0, Math.PI * 2);
                this.ctx.fill();

                if (this.settings.glowEffect) {
                    this.ctx.shadowBlur = 15;
                    this.ctx.shadowColor = star.color;
                    this.ctx.fill();
                    this.ctx.shadowBlur = 0;
                }

            } else {
                // NORMAL MODE - stars fly towards viewer
                // Reset explosion velocity
                star.explosionVx = 0;
                star.explosionVy = 0;

                // Move star towards viewer
                star.z -= speed;

                // Reset star if it goes past viewer
                if (star.z <= 0) {
                    star.z = this.canvas.width;
                    star.x = Math.random() * this.canvas.width;
                    star.y = Math.random() * this.canvas.height;
                    star.color = colors[Math.floor(Math.random() * colors.length)];
                }

                // Calculate star position (perspective)
                const k = 128 / star.z;
                const px = (star.x - centerX) * k + centerX;
                const py = (star.y - centerY) * k + centerY;

                // Calculate star size based on distance
                const size = (1 - star.z / this.canvas.width) * 3;

                // Draw star
                this.ctx.fillStyle = star.color;
                this.ctx.beginPath();
                this.ctx.arc(px, py, size, 0, Math.PI * 2);
                this.ctx.fill();

                if (this.settings.glowEffect) {
                    this.ctx.shadowBlur = 5;
                    this.ctx.shadowColor = star.color;
                    this.ctx.fill();
                    this.ctx.shadowBlur = 0;
                }

                // Draw star trail
                const trailLength = speed * 2;
                const tx = (star.x - centerX) * (128 / (star.z + trailLength)) + centerX;
                const ty = (star.y - centerY) * (128 / (star.z + trailLength)) + centerY;

                this.ctx.strokeStyle = star.color;
                this.ctx.lineWidth = size / 2;
                this.ctx.globalAlpha = 0.5;
                this.ctx.beginPath();
                this.ctx.moveTo(px, py);
                this.ctx.lineTo(tx, ty);
                this.ctx.stroke();
                this.ctx.globalAlpha = 1.0;
            }
        }
    }

    drawSpeaker() {
        // Speaker/Woofer visualizer with side waveforms
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Dark background
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Audio reactivity
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const intensity = (average / 255) * (this.settings.sensitivity / 5);

        // Speaker dimensions
        const speakerWidth = Math.min(this.canvas.width * 0.35, 350);
        const speakerHeight = speakerWidth * 1.2;
        const speakerX = centerX - speakerWidth / 2;
        const speakerY = centerY - speakerHeight / 2;

        // Speaker cabinet (metallic gray)
        const cabinetGradient = this.ctx.createLinearGradient(speakerX, speakerY, speakerX, speakerY + speakerHeight);
        cabinetGradient.addColorStop(0, '#4a4a4a');
        cabinetGradient.addColorStop(0.5, '#2a2a2a');
        cabinetGradient.addColorStop(1, '#4a4a4a');
        this.ctx.fillStyle = cabinetGradient;
        this.ctx.fillRect(speakerX, speakerY, speakerWidth, speakerHeight);

        // Speaker border
        this.ctx.strokeStyle = '#666';
        this.ctx.lineWidth = 3;
        this.ctx.strokeRect(speakerX, speakerY, speakerWidth, speakerHeight);

        // Speaker cone
        const coneRadius = speakerWidth * 0.4;
        const coneY = centerY;

        // Outer ring (screws)
        const screwCount = 8;
        for (let i = 0; i < screwCount; i++) {
            const angle = (i / screwCount) * Math.PI * 2;
            const screwX = centerX + Math.cos(angle) * (coneRadius + 15);
            const screwY = coneY + Math.sin(angle) * (coneRadius + 15);

            this.ctx.fillStyle = '#333';
            this.ctx.beginPath();
            this.ctx.arc(screwX, screwY, 4, 0, Math.PI * 2);
            this.ctx.fill();
        }

        // Speaker cone (pulsing with audio)
        const pulseRadius = coneRadius + intensity * 20;

        // Cone gradient (metallic silver)
        const coneGradient = this.ctx.createRadialGradient(centerX, coneY, 0, centerX, coneY, pulseRadius);
        coneGradient.addColorStop(0, '#888');
        coneGradient.addColorStop(0.3, '#555');
        coneGradient.addColorStop(0.6, '#333');
        coneGradient.addColorStop(1, '#1a1a1a');

        this.ctx.fillStyle = coneGradient;
        this.ctx.beginPath();
        this.ctx.arc(centerX, coneY, pulseRadius, 0, Math.PI * 2);
        this.ctx.fill();

        // Cone rings (for depth)
        for (let i = 1; i <= 3; i++) {
            const ringRadius = pulseRadius * (i / 4);
            this.ctx.strokeStyle = `rgba(100, 100, 100, ${0.3 / i})`;
            this.ctx.lineWidth = 2;
            this.ctx.beginPath();
            this.ctx.arc(centerX, coneY, ringRadius, 0, Math.PI * 2);
            this.ctx.stroke();
        }

        // Center dust cap (pulsing)
        const dustCapRadius = pulseRadius * 0.25;
        const dustCapGradient = this.ctx.createRadialGradient(centerX, coneY, 0, centerX, coneY, dustCapRadius);
        dustCapGradient.addColorStop(0, '#666');
        dustCapGradient.addColorStop(1, '#222');

        this.ctx.fillStyle = dustCapGradient;
        this.ctx.beginPath();
        this.ctx.arc(centerX, coneY, dustCapRadius, 0, Math.PI * 2);
        this.ctx.fill();

        // Dust cap highlight
        this.ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
        this.ctx.beginPath();
        this.ctx.arc(centerX - dustCapRadius * 0.3, coneY - dustCapRadius * 0.3, dustCapRadius * 0.4, 0, Math.PI * 2);
        this.ctx.fill();

        // Left waveform
        this.analyser.getByteTimeDomainData(this.dataArray);
        const waveformWidth = (this.canvas.width - speakerWidth) / 2 - 40;
        const waveformHeight = speakerHeight;
        const leftWaveX = 20;
        const waveformY = speakerY;

        this.ctx.strokeStyle = '#00aaff';
        this.ctx.lineWidth = 2;
        this.ctx.shadowBlur = 10;
        this.ctx.shadowColor = '#00aaff';

        this.ctx.beginPath();
        const sliceWidth = waveformWidth / this.dataArray.length;

        for (let i = 0; i < this.dataArray.length; i++) {
            const v = (this.dataArray[i] - 128) / 128.0;
            const y = waveformY + waveformHeight / 2 + (v * waveformHeight / 2 * (this.settings.sensitivity / 5));
            const x = leftWaveX + i * sliceWidth;

            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }
        this.ctx.stroke();

        // Right waveform (mirrored)
        const rightWaveX = speakerX + speakerWidth + 20;

        this.ctx.beginPath();
        for (let i = 0; i < this.dataArray.length; i++) {
            const v = (this.dataArray[i] - 128) / 128.0;
            const y = waveformY + waveformHeight / 2 + (v * waveformHeight / 2 * (this.settings.sensitivity / 5));
            const x = rightWaveX + i * sliceWidth;

            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }
        this.ctx.stroke();
        this.ctx.shadowBlur = 0;
    }

    drawNeonWaves() {
        // Neon Waves - flowing layered sine waves with rainbow colors
        // Black background
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Time for animation
        const time = Date.now() * 0.001;

        // Audio reactivity
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const intensity = (average / 255) * (this.settings.sensitivity / 5);

        // Clean rainbow colors (fewer, more distinct)
        const rainbowColors = [
            '#ff0000', // Red
            '#ff8800', // Orange
            '#ffff00', // Yellow
            '#00ff00', // Green
            '#00ffff', // Cyan
            '#0088ff', // Light Blue
            '#0000ff', // Blue
            '#8800ff'  // Purple
        ];

        // Fewer layers for cleaner look
        const numLayers = 8;
        const centerY = this.canvas.height / 2;

        // Draw wave layers
        for (let layer = 0; layer < numLayers; layer++) {
            const color = rainbowColors[layer];

            // Wave parameters - bigger amplitude, more spacing
            const amplitude = 100 + intensity * 80;
            const frequency = 0.004;
            const phase = time * 0.8 + (layer * 0.4);
            const yOffset = (layer - numLayers / 2) * 25; // More spacing between waves

            // Draw wave with strong glow
            this.ctx.strokeStyle = color;
            this.ctx.lineWidth = 3;
            this.ctx.shadowBlur = 20;
            this.ctx.shadowColor = color;

            this.ctx.beginPath();

            for (let x = 0; x <= this.canvas.width; x += 3) {
                // Smooth flowing sine wave
                const y = centerY + yOffset + Math.sin(x * frequency + phase) * amplitude;

                if (x === 0) {
                    this.ctx.moveTo(x, y);
                } else {
                    this.ctx.lineTo(x, y);
                }
            }

            this.ctx.stroke();

            // Extra glow pass
            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 30;
                this.ctx.lineWidth = 2;
                this.ctx.stroke();
            }
        }

        this.ctx.shadowBlur = 0;
    }

    drawVinyl() {
        // Spinning vinyl record that pops with loud sound
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Dark background
        this.ctx.fillStyle = '#1a1a1a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Audio reactivity
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const intensity = (average / 255) * (this.settings.sensitivity / 5);

        // Pop effect - vinyl expands when loud
        const baseRadius = Math.min(this.canvas.width, this.canvas.height) * 0.35;
        const vinylRadius = baseRadius + intensity * 50;

        // Initialize rotation if needed
        if (!this.vinylRotation) {
            this.vinylRotation = 0;
        }
        // Spin faster with louder music
        this.vinylRotation += 0.01 + intensity * 0.05;

        // Draw vinyl record
        // Outer edge (black vinyl)
        this.ctx.fillStyle = '#0a0a0a';
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, vinylRadius, 0, Math.PI * 2);
        this.ctx.fill();

        // Vinyl grooves (rotating)
        this.ctx.save();
        this.ctx.translate(centerX, centerY);
        this.ctx.rotate(this.vinylRotation);

        const grooveCount = 40;
        for (let i = 0; i < grooveCount; i++) {
            const grooveRadius = vinylRadius * 0.3 + (i / grooveCount) * (vinylRadius * 0.6);
            this.ctx.strokeStyle = `rgba(50, 50, 50, ${0.3 + Math.sin(i * 0.5) * 0.2})`;
            this.ctx.lineWidth = 1;
            this.ctx.beginPath();
            this.ctx.arc(0, 0, grooveRadius, 0, Math.PI * 2);
            this.ctx.stroke();
        }

        this.ctx.restore();

        // Center label
        const labelRadius = vinylRadius * 0.25;

        // RGB cycling color for label
        const time = Date.now() * 0.001;
        const r = Math.floor(128 + Math.sin(time * 2) * 127);
        const g = Math.floor(128 + Math.sin(time * 2 + Math.PI * 2 / 3) * 127);
        const b = Math.floor(128 + Math.sin(time * 2 + Math.PI * 4 / 3) * 127);
        const rgbColor = `rgb(${r}, ${g}, ${b})`;

        // Label background (solid RGB color)
        this.ctx.fillStyle = rgbColor;
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, labelRadius, 0, Math.PI * 2);
        this.ctx.fill();

        // Label border (also RGB with glow)
        this.ctx.strokeStyle = rgbColor;
        this.ctx.lineWidth = 3;
        this.ctx.shadowBlur = 15;
        this.ctx.shadowColor = rgbColor;
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, labelRadius, 0, Math.PI * 2);
        this.ctx.stroke();
        this.ctx.shadowBlur = 0;

        // Center hole
        this.ctx.fillStyle = '#000000';
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, vinylRadius * 0.05, 0, Math.PI * 2);
        this.ctx.fill();

        // Spectrum around the vinyl
        const colors = this.colorSchemes[this.settings.colorScheme];
        const barCount = 64;
        const barRadius = vinylRadius + 20;

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * 80 * (this.settings.sensitivity / 5);

            const angle = (i / barCount) * Math.PI * 2;
            const x1 = centerX + Math.cos(angle) * barRadius;
            const y1 = centerY + Math.sin(angle) * barRadius;
            const x2 = centerX + Math.cos(angle) * (barRadius + barHeight);
            const y2 = centerY + Math.sin(angle) * (barRadius + barHeight);

            const colorIndex = Math.floor((i / barCount) * colors.length);
            this.ctx.strokeStyle = colors[colorIndex % colors.length];
            this.ctx.lineWidth = 3;

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 10;
                this.ctx.shadowColor = colors[colorIndex % colors.length];
            }

            this.ctx.beginPath();
            this.ctx.moveTo(x1, y1);
            this.ctx.lineTo(x2, y2);
            this.ctx.stroke();
        }

        this.ctx.shadowBlur = 0;
    }

    drawSynth() {
        // Retro synthesizer/sampler visualizer
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Dark background
        this.ctx.fillStyle = '#1a1a1a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Audio reactivity
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const intensity = (average / 255) * (this.settings.sensitivity / 5);

        // Main unit dimensions
        const unitWidth = Math.min(this.canvas.width * 0.9, 900);
        const unitHeight = Math.min(this.canvas.height * 0.7, 400);
        const unitX = centerX - unitWidth / 2;
        const unitY = centerY - unitHeight / 2;

        // Rack unit body (teal/cyan color like the image)
        const bodyGradient = this.ctx.createLinearGradient(unitX, unitY, unitX, unitY + unitHeight);
        bodyGradient.addColorStop(0, '#4a6b6b');
        bodyGradient.addColorStop(0.5, '#3a5555');
        bodyGradient.addColorStop(1, '#2a4444');
        this.ctx.fillStyle = bodyGradient;
        this.ctx.fillRect(unitX, unitY, unitWidth, unitHeight);

        // Border
        this.ctx.strokeStyle = '#5a7b7b';
        this.ctx.lineWidth = 3;
        this.ctx.strokeRect(unitX, unitY, unitWidth, unitHeight);

        // Top display panel (dark)
        const topPanelHeight = unitHeight * 0.25;
        this.ctx.fillStyle = '#0a0a0a';
        this.ctx.fillRect(unitX + 10, unitY + 10, unitWidth - 20, topPanelHeight);

        // Orange text display (like the image)
        this.ctx.fillStyle = '#ff6600';
        this.ctx.font = '14px "Courier New"';
        this.ctx.textAlign = 'left';
        this.ctx.shadowBlur = 5;
        this.ctx.shadowColor = '#ff6600';
        this.ctx.fillText('RETRO SAMPLER 2000', unitX + 20, unitY + 30);
        this.ctx.fillText(`LEVEL: ${Math.floor(intensity * 100)}%`, unitX + 20, unitY + 50);
        this.ctx.fillText(`FREQ: ${Math.floor(440 + intensity * 1000)} Hz`, unitX + 20, unitY + 70);
        this.ctx.shadowBlur = 0;

        // Main display area
        const displayY = unitY + topPanelHeight + 20;
        const displayHeight = unitHeight * 0.5;

        // Left VU meter (circular, orange)
        const vuRadius = displayHeight * 0.35;
        const leftVUX = unitX + unitWidth * 0.2;
        const vuY = displayY + displayHeight / 2;

        // VU meter background
        this.ctx.fillStyle = '#1a0f00';
        this.ctx.beginPath();
        this.ctx.arc(leftVUX, vuY, vuRadius, 0, Math.PI * 2);
        this.ctx.fill();

        // VU meter segments (orange)
        const segmentCount = 20;
        for (let i = 0; i < segmentCount; i++) {
            const angle = -Math.PI * 0.75 + (i / segmentCount) * Math.PI * 1.5;
            const isActive = i < intensity * segmentCount;

            this.ctx.strokeStyle = isActive ? '#ff8800' : '#332200';
            this.ctx.lineWidth = 4;
            this.ctx.shadowBlur = isActive ? 10 : 0;
            this.ctx.shadowColor = '#ff8800';

            const x1 = leftVUX + Math.cos(angle) * vuRadius * 0.7;
            const y1 = vuY + Math.sin(angle) * vuRadius * 0.7;
            const x2 = leftVUX + Math.cos(angle) * vuRadius * 0.9;
            const y2 = vuY + Math.sin(angle) * vuRadius * 0.9;

            this.ctx.beginPath();
            this.ctx.moveTo(x1, y1);
            this.ctx.lineTo(x2, y2);
            this.ctx.stroke();
        }
        this.ctx.shadowBlur = 0;

        // Center waveform display
        const waveformX = unitX + unitWidth * 0.4;
        const waveformWidth = unitWidth * 0.3;
        const waveformHeight = displayHeight * 0.8;
        const waveformY = displayY + (displayHeight - waveformHeight) / 2;

        // Waveform background
        this.ctx.fillStyle = '#0a0a0a';
        this.ctx.fillRect(waveformX, waveformY, waveformWidth, waveformHeight);

        // Draw waveform
        this.analyser.getByteTimeDomainData(this.dataArray);
        this.ctx.strokeStyle = '#ff8800';
        this.ctx.lineWidth = 2;
        this.ctx.shadowBlur = 5;
        this.ctx.shadowColor = '#ff8800';

        this.ctx.beginPath();
        const sliceWidth = waveformWidth / this.dataArray.length;

        for (let i = 0; i < this.dataArray.length; i++) {
            const v = (this.dataArray[i] - 128) / 128.0;
            const y = waveformY + waveformHeight / 2 + (v * waveformHeight / 2);
            const x = waveformX + i * sliceWidth;

            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }
        this.ctx.stroke();
        this.ctx.shadowBlur = 0;

        // Right VU meter (circular, orange)
        const rightVUX = unitX + unitWidth * 0.8;

        // VU meter background
        this.ctx.fillStyle = '#1a0f00';
        this.ctx.beginPath();
        this.ctx.arc(rightVUX, vuY, vuRadius, 0, Math.PI * 2);
        this.ctx.fill();

        // VU meter segments
        for (let i = 0; i < segmentCount; i++) {
            const angle = -Math.PI * 0.75 + (i / segmentCount) * Math.PI * 1.5;
            const isActive = i < intensity * segmentCount;

            this.ctx.strokeStyle = isActive ? '#ff8800' : '#332200';
            this.ctx.lineWidth = 4;
            this.ctx.shadowBlur = isActive ? 10 : 0;
            this.ctx.shadowColor = '#ff8800';

            const x1 = rightVUX + Math.cos(angle) * vuRadius * 0.7;
            const y1 = vuY + Math.sin(angle) * vuRadius * 0.7;
            const x2 = rightVUX + Math.cos(angle) * vuRadius * 0.9;
            const y2 = vuY + Math.sin(angle) * vuRadius * 0.9;

            this.ctx.beginPath();
            this.ctx.moveTo(x1, y1);
            this.ctx.lineTo(x2, y2);
            this.ctx.stroke();
        }
        this.ctx.shadowBlur = 0;

        // Bottom controls area
        const controlsY = displayY + displayHeight + 10;

        // Rack screws
        const screwRadius = 4;
        const screwPositions = [
            [unitX + 15, unitY + 15],
            [unitX + unitWidth - 15, unitY + 15],
            [unitX + 15, unitY + unitHeight - 15],
            [unitX + unitWidth - 15, unitY + unitHeight - 15]
        ];

        this.ctx.fillStyle = '#333';
        for (const [sx, sy] of screwPositions) {
            this.ctx.beginPath();
            this.ctx.arc(sx, sy, screwRadius, 0, Math.PI * 2);
            this.ctx.fill();
        }
    }

    drawRadial1() {
        // Radial visualizer with pulsing rings
        const colors = this.colorSchemes[this.settings.colorScheme];
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Audio reactivity
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const intensity = (average / 255) * (this.settings.sensitivity / 5);

        // Number of rings
        const ringCount = 12;
        const maxRadius = Math.min(centerX, centerY) * 0.9;

        for (let ring = 0; ring < ringCount; ring++) {
            const ringRadius = (maxRadius / ringCount) * (ring + 1);
            const colorIndex = ring % colors.length;

            // Calculate segments for this ring
            const segmentCount = 32 + ring * 4;

            for (let i = 0; i < segmentCount; i++) {
                const dataIndex = Math.floor(i * this.dataArray.length / segmentCount);
                const value = this.dataArray[dataIndex] / 255;
                const segmentHeight = value * 30 * (this.settings.sensitivity / 5);

                const angle = (i / segmentCount) * Math.PI * 2;
                const x1 = centerX + Math.cos(angle) * ringRadius;
                const y1 = centerY + Math.sin(angle) * ringRadius;
                const x2 = centerX + Math.cos(angle) * (ringRadius + segmentHeight);
                const y2 = centerY + Math.sin(angle) * (ringRadius + segmentHeight);

                this.ctx.strokeStyle = colors[colorIndex];
                this.ctx.lineWidth = 2;

                if (this.settings.glowEffect) {
                    this.ctx.shadowBlur = 10;
                    this.ctx.shadowColor = colors[colorIndex];
                }

                this.ctx.beginPath();
                this.ctx.moveTo(x1, y1);
                this.ctx.lineTo(x2, y2);
                this.ctx.stroke();
            }
        }
        this.ctx.shadowBlur = 0;
    }

    drawRadial2() {
        // Radial visualizer with spiral bars
        const colors = this.colorSchemes[this.settings.colorScheme];
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Audio reactivity
        const time = Date.now() * 0.001;

        // Draw rotating radial bars
        const barCount = 64;
        const maxRadius = Math.min(centerX, centerY) * 0.8;

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * maxRadius * (this.settings.sensitivity / 5);

            const angle = (i / barCount) * Math.PI * 2 + time * 0.5;
            const innerRadius = maxRadius * 0.2;
            const outerRadius = innerRadius + barHeight;

            const x1 = centerX + Math.cos(angle) * innerRadius;
            const y1 = centerY + Math.sin(angle) * innerRadius;
            const x2 = centerX + Math.cos(angle) * outerRadius;
            const y2 = centerY + Math.sin(angle) * outerRadius;

            const colorIndex = Math.floor((i / barCount) * colors.length);
            this.ctx.strokeStyle = colors[colorIndex % colors.length];
            this.ctx.lineWidth = 4;

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 15;
                this.ctx.shadowColor = colors[colorIndex % colors.length];
            }

            this.ctx.beginPath();
            this.ctx.moveTo(x1, y1);
            this.ctx.lineTo(x2, y2);
            this.ctx.stroke();
        }
        this.ctx.shadowBlur = 0;
    }

    drawBars() {
        // Windows Media Center style bars with reflection
        const colors = this.colorSchemes[this.settings.colorScheme];
        const barCount = 64;
        const barWidth = this.canvas.width / barCount;
        const maxHeight = this.canvas.height * 0.4;

        // Black background
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * maxHeight * (this.settings.sensitivity / 5);

            const x = i * barWidth;
            const y = this.canvas.height / 2 - barHeight;

            // Main bar
            const colorIndex = Math.floor((i / barCount) * colors.length);
            const gradient = this.ctx.createLinearGradient(x, y, x, y + barHeight);
            gradient.addColorStop(0, colors[colorIndex % colors.length]);
            gradient.addColorStop(1, '#000000');

            this.ctx.fillStyle = gradient;
            this.ctx.fillRect(x, y, barWidth - 2, barHeight);

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 10;
                this.ctx.shadowColor = colors[colorIndex % colors.length];
                this.ctx.fillRect(x, y, barWidth - 2, barHeight);
                this.ctx.shadowBlur = 0;
            }

            // Reflection
            const reflectionGradient = this.ctx.createLinearGradient(x, this.canvas.height / 2, x, this.canvas.height / 2 + barHeight * 0.5);
            reflectionGradient.addColorStop(0, colors[colorIndex % colors.length]);
            reflectionGradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

            this.ctx.globalAlpha = 0.3;
            this.ctx.fillStyle = reflectionGradient;
            this.ctx.fillRect(x, this.canvas.height / 2, barWidth - 2, barHeight * 0.5);
            this.ctx.globalAlpha = 1.0;
        }
    }

    drawScope() {
        // Windows Media Center style oscilloscope
        const colors = this.colorSchemes[this.settings.colorScheme];

        // Black background with fade
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Get time domain data
        this.analyser.getByteTimeDomainData(this.dataArray);

        // Draw multiple offset traces for depth effect
        const traceCount = 3;

        for (let trace = 0; trace < traceCount; trace++) {
            const colorIndex = trace % colors.length;
            this.ctx.strokeStyle = colors[colorIndex];
            this.ctx.lineWidth = 2;

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 15;
                this.ctx.shadowColor = colors[colorIndex];
            }

            this.ctx.beginPath();
            const sliceWidth = this.canvas.width / this.dataArray.length;
            const yOffset = (trace - traceCount / 2) * 20;

            for (let i = 0; i < this.dataArray.length; i++) {
                const v = (this.dataArray[i] - 128) / 128.0;
                const y = this.canvas.height / 2 + yOffset + (v * this.canvas.height / 3 * (this.settings.sensitivity / 5));
                const x = i * sliceWidth;

                if (i === 0) {
                    this.ctx.moveTo(x, y);
                } else {
                    this.ctx.lineTo(x, y);
                }
            }

            this.ctx.stroke();
        }

        this.ctx.shadowBlur = 0;
    }

    drawMacOS() {
        // macOS/iTunes/Apple Music style visualizer
        // Smooth gradient background
        const bgGradient = this.ctx.createLinearGradient(0, 0, 0, this.canvas.height);
        bgGradient.addColorStop(0, '#1a1a2e');
        bgGradient.addColorStop(1, '#0f0f1e');
        this.ctx.fillStyle = bgGradient;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Bar settings
        const barCount = 80;
        const barWidth = (this.canvas.width / barCount) * 0.8;
        const spacing = this.canvas.width / barCount;
        const maxHeight = this.canvas.height * 0.7;

        // Initialize bar heights if needed
        if (!this.macOSBarHeights) {
            this.macOSBarHeights = new Array(barCount).fill(0);
        }

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const targetHeight = (this.dataArray[dataIndex] / 255) * maxHeight * (this.settings.sensitivity / 5);

            // Smooth animation (ease towards target)
            this.macOSBarHeights[i] += (targetHeight - this.macOSBarHeights[i]) * 0.3;

            const barHeight = this.macOSBarHeights[i];
            const x = i * spacing + (spacing - barWidth) / 2;
            const y = this.canvas.height - barHeight;

            // Create smooth gradient for each bar
            const barGradient = this.ctx.createLinearGradient(x, y, x, y + barHeight);

            // Apple-style colors (blue to purple gradient)
            const hue = 200 + (i / barCount) * 80; // Blue to purple
            const saturation = 70;
            const lightness = 50 + (barHeight / maxHeight) * 20;

            barGradient.addColorStop(0, `hsl(${hue}, ${saturation}%, ${lightness + 20}%)`);
            barGradient.addColorStop(0.5, `hsl(${hue}, ${saturation}%, ${lightness}%)`);
            barGradient.addColorStop(1, `hsl(${hue}, ${saturation}%, ${lightness - 10}%)`);

            this.ctx.fillStyle = barGradient;

            // Rounded rectangle
            this.ctx.beginPath();
            const radius = barWidth / 2;
            this.ctx.roundRect(x, y, barWidth, barHeight, [radius, radius, 0, 0]);
            this.ctx.fill();

            // Subtle glow
            if (this.settings.glowEffect && barHeight > 20) {
                this.ctx.shadowBlur = 15;
                this.ctx.shadowColor = `hsl(${hue}, ${saturation}%, ${lightness}%)`;
                this.ctx.fill();
                this.ctx.shadowBlur = 0;
            }

            // Highlight on top
            if (barHeight > 10) {
                const highlightGradient = this.ctx.createLinearGradient(x, y, x, y + 10);
                highlightGradient.addColorStop(0, `hsla(${hue}, ${saturation}%, ${lightness + 30}%, 0.6)`);
                highlightGradient.addColorStop(1, `hsla(${hue}, ${saturation}%, ${lightness}%, 0)`);

                this.ctx.fillStyle = highlightGradient;
                this.ctx.beginPath();
                this.ctx.roundRect(x, y, barWidth, Math.min(10, barHeight), [radius, radius, 0, 0]);
                this.ctx.fill();
            }
        }
    }

    drawRetro() {
        // Retro 80s synthwave/vaporwave visualizer
        // Black background
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Audio reactivity
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const intensity = (average / 255) * (this.settings.sensitivity / 5);

        // Stars
        if (!this.retroStars) {
            this.retroStars = [];
            for (let i = 0; i < 100; i++) {
                this.retroStars.push({
                    x: Math.random() * this.canvas.width,
                    y: Math.random() * this.canvas.height * 0.4,
                    size: Math.random() * 2
                });
            }
        }

        this.ctx.fillStyle = '#ffffff';
        for (const star of this.retroStars) {
            this.ctx.fillRect(star.x, star.y, star.size, star.size);
        }

        // Sunset/Sun
        const sunY = this.canvas.height * 0.3;
        const sunRadius = 80 + intensity * 30;

        // Sun with horizontal stripes
        const stripeCount = 12;
        const stripeHeight = (sunRadius * 2) / stripeCount;

        for (let i = 0; i < stripeCount; i++) {
            const y = sunY - sunRadius + i * stripeHeight;
            const progress = i / stripeCount;

            // Gradient from yellow to pink/red
            let color;
            if (progress < 0.3) {
                color = '#ffff88';
            } else if (progress < 0.5) {
                color = '#ffdd66';
            } else if (progress < 0.7) {
                color = '#ffaa44';
            } else {
                color = '#ff6644';
            }

            this.ctx.fillStyle = color;

            // Calculate stripe width (circular)
            const relY = (y + stripeHeight / 2 - sunY) / sunRadius;
            if (Math.abs(relY) <= 1) {
                const stripeWidth = Math.sqrt(1 - relY * relY) * sunRadius * 2;
                const stripeX = this.canvas.width / 2 - stripeWidth / 2;
                this.ctx.fillRect(stripeX, y, stripeWidth, stripeHeight);
            }
        }

        // Horizon line with reflection
        const horizonY = this.canvas.height * 0.45;

        // Sky gradient (purple/pink)
        const skyGradient = this.ctx.createLinearGradient(0, horizonY - 100, 0, horizonY);
        skyGradient.addColorStop(0, '#4a0e4e');
        skyGradient.addColorStop(0.5, '#81007f');
        skyGradient.addColorStop(1, '#ff006e');
        this.ctx.fillStyle = skyGradient;
        this.ctx.fillRect(0, horizonY - 100, this.canvas.width, 100);

        // Water reflection gradient (cyan/blue)
        const waterGradient = this.ctx.createLinearGradient(0, horizonY, 0, horizonY + 100);
        waterGradient.addColorStop(0, '#00d9ff');
        waterGradient.addColorStop(1, '#0066ff');
        this.ctx.fillStyle = waterGradient;
        this.ctx.fillRect(0, horizonY, this.canvas.width, 100);

        // Perspective grid floor
        const gridY = horizonY + 100;
        const gridHeight = this.canvas.height - gridY;

        // Grid lines (perspective)
        this.ctx.strokeStyle = '#00ffff';
        this.ctx.lineWidth = 2;

        // Horizontal lines
        const hLineCount = 15;
        for (let i = 0; i < hLineCount; i++) {
            const progress = i / hLineCount;
            const y = gridY + progress * gridHeight;

            // Audio reactive spacing
            const offset = Math.sin(progress * Math.PI) * intensity * 20;

            this.ctx.beginPath();
            this.ctx.moveTo(0, y + offset);
            this.ctx.lineTo(this.canvas.width, y + offset);
            this.ctx.stroke();
        }

        // Vertical lines (perspective)
        const vLineCount = 20;
        const centerX = this.canvas.width / 2;

        for (let i = 0; i < vLineCount; i++) {
            const offset = (i - vLineCount / 2) * 50;

            // Perspective calculation
            const topX = centerX + offset * 0.3;
            const bottomX = centerX + offset * 2;

            // Audio reactive
            const audioOffset = intensity * 10 * Math.sin(i * 0.5);

            this.ctx.beginPath();
            this.ctx.moveTo(topX + audioOffset, gridY);
            this.ctx.lineTo(bottomX + audioOffset, this.canvas.height);
            this.ctx.stroke();
        }

        // Spectrum bars on grid (audio reactive)
        const barCount = 32;
        const barSpacing = this.canvas.width / barCount;

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * 60 * (this.settings.sensitivity / 5);

            if (barHeight > 5) {
                const x = i * barSpacing;
                const y = gridY - barHeight;

                const gradient = this.ctx.createLinearGradient(x, y, x, gridY);
                gradient.addColorStop(0, '#ff00ff');
                gradient.addColorStop(1, '#00ffff');

                this.ctx.fillStyle = gradient;
                this.ctx.fillRect(x, y, barSpacing - 2, barHeight);
            }
        }
    }

    drawCRT() {
        // Vintage CRT oscilloscope with green phosphor
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Dark background (CRT off state)
        this.ctx.fillStyle = '#0a0a0a';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // CRT screen area (circular)
        const screenRadius = Math.min(centerX, centerY) * 0.8;

        // Screen glow background
        const glowGradient = this.ctx.createRadialGradient(centerX, centerY, 0, centerX, centerY, screenRadius);
        glowGradient.addColorStop(0, '#1a2a1a');
        glowGradient.addColorStop(0.7, '#0f1f0f');
        glowGradient.addColorStop(1, '#0a0a0a');
        this.ctx.fillStyle = glowGradient;
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, screenRadius, 0, Math.PI * 2);
        this.ctx.fill();

        // Get time domain data
        this.analyser.getByteTimeDomainData(this.dataArray);

        // Draw Lissajous curve (X-Y mode oscilloscope)
        this.ctx.strokeStyle = '#00ff66';
        this.ctx.lineWidth = 2;
        this.ctx.shadowBlur = 15;
        this.ctx.shadowColor = '#00ff66';

        this.ctx.beginPath();

        const scale = screenRadius * 0.6 * (this.settings.sensitivity / 5);
        const points = Math.min(this.dataArray.length, 500);

        for (let i = 0; i < points; i++) {
            // Create Lissajous pattern using audio data
            const t = (i / points) * Math.PI * 2;

            // Use audio data for X and Y with phase shift
            const dataIndex1 = Math.floor(i * this.dataArray.length / points);
            const dataIndex2 = Math.floor(((i + points / 4) % points) * this.dataArray.length / points);

            const x1 = (this.dataArray[dataIndex1] - 128) / 128.0;
            const y1 = (this.dataArray[dataIndex2] - 128) / 128.0;

            // Add some mathematical curves for aesthetic
            const x = centerX + (x1 * scale + Math.sin(t * 3) * scale * 0.3);
            const y = centerY + (y1 * scale + Math.cos(t * 2) * scale * 0.3);

            if (i === 0) {
                this.ctx.moveTo(x, y);
            } else {
                this.ctx.lineTo(x, y);
            }
        }

        this.ctx.stroke();

        // Extra glow pass
        this.ctx.shadowBlur = 25;
        this.ctx.lineWidth = 1;
        this.ctx.stroke();

        this.ctx.shadowBlur = 0;

        // CRT screen border/bezel
        this.ctx.strokeStyle = '#2a2a2a';
        this.ctx.lineWidth = 8;
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, screenRadius, 0, Math.PI * 2);
        this.ctx.stroke();

        // Outer metal frame
        this.ctx.strokeStyle = '#4a4a4a';
        this.ctx.lineWidth = 3;
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, screenRadius + 15, 0, Math.PI * 2);
        this.ctx.stroke();

        // Graticule (grid lines) - faint
        this.ctx.strokeStyle = 'rgba(0, 255, 102, 0.15)';
        this.ctx.lineWidth = 1;

        // Center crosshair
        this.ctx.beginPath();
        this.ctx.moveTo(centerX - screenRadius * 0.7, centerY);
        this.ctx.lineTo(centerX + screenRadius * 0.7, centerY);
        this.ctx.stroke();

        this.ctx.beginPath();
        this.ctx.moveTo(centerX, centerY - screenRadius * 0.7);
        this.ctx.lineTo(centerX, centerY + screenRadius * 0.7);
        this.ctx.stroke();

        // Circular graticule rings
        for (let i = 1; i <= 3; i++) {
            this.ctx.beginPath();
            this.ctx.arc(centerX, centerY, screenRadius * 0.7 * (i / 3), 0, Math.PI * 2);
            this.ctx.stroke();
        }

        // Phosphor persistence effect (fade trails)
        this.ctx.fillStyle = 'rgba(10, 10, 10, 0.05)';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    }

    drawStocks() {
        // Stock market graph visualizer - always going up!
        // Black background with blue stripes
        this.ctx.fillStyle = '#000000';
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Initialize stock data if needed
        if (!this.stockData) {
            this.stockData = [];
            this.stockOffset = 0; // Camera offset
            const startY = this.canvas.height / 2;
            for (let i = 0; i < this.canvas.width; i++) {
                this.stockData.push(startY);
            }
        }

        // Get frequency data for bass detection
        this.analyser.getByteFrequencyData(this.dataArray);

        // Detect SUB-BASS (very low frequencies only - first 3%)
        const subBassRange = Math.floor(this.dataArray.length * 0.03);
        let subBassLevel = 0;
        for (let i = 0; i < subBassRange; i++) {
            subBassLevel += this.dataArray[i];
        }
        subBassLevel = subBassLevel / subBassRange / 255;

        // Get mid-high frequencies for upward movement
        let midHighLevel = 0;
        const midStart = Math.floor(this.dataArray.length * 0.15);
        const midEnd = Math.floor(this.dataArray.length * 0.5);
        for (let i = midStart; i < midEnd; i++) {
            midHighLevel += this.dataArray[i];
        }
        midHighLevel = midHighLevel / (midEnd - midStart) / 255;

        // Shift all data left (scroll effect)
        this.stockData.shift();

        // Calculate new value - MOSTLY GREEN
        const lastValue = this.stockData[this.stockData.length - 1];
        let targetValue;

        // Very high sub-bass threshold (0.8) - only extreme bass causes dips
        if (subBassLevel > 0.8) {
            // EXTREME SUB-BASS detected - RED DIP (smaller dip)
            targetValue = lastValue + (subBassLevel * 40 * (this.settings.sensitivity / 5));
        } else {
            // Normal - GREEN UP (always going up!)
            const baseUpward = 12; // Always go up at least this much
            const audioBoost = midHighLevel * 40 * (this.settings.sensitivity / 5);
            targetValue = lastValue - (baseUpward + audioBoost);
        }

        // Smooth the movement (exponential moving average)
        if (!this.stockSmoothValue) {
            this.stockSmoothValue = targetValue;
        }
        const smoothing = 0.3; // Lower = smoother (0-1)
        this.stockSmoothValue += (targetValue - this.stockSmoothValue) * smoothing;

        this.stockData.push(this.stockSmoothValue);

        // Update camera offset to follow the line
        const currentY = this.stockData[this.stockData.length - 1];
        const targetOffset = currentY - this.canvas.height / 2;
        this.stockOffset += (targetOffset - this.stockOffset) * 0.1; // Smooth follow

        // Draw blue horizontal grid stripes
        this.ctx.strokeStyle = '#0066ff';
        this.ctx.lineWidth = 1;

        const gridSpacing = 50;
        const startGridY = Math.floor(this.stockOffset / gridSpacing) * gridSpacing;

        for (let i = -5; i < 20; i++) {
            const y = startGridY + i * gridSpacing - this.stockOffset;
            if (y >= 0 && y <= this.canvas.height) {
                this.ctx.beginPath();
                this.ctx.moveTo(0, y);
                this.ctx.lineTo(this.canvas.width, y);
                this.ctx.stroke();
            }
        }

        // Draw the stock line
        this.ctx.lineWidth = 3;

        for (let i = 1; i < this.stockData.length; i++) {
            const x1 = i - 1;
            const y1 = this.stockData[i - 1] - this.stockOffset;
            const x2 = i;
            const y2 = this.stockData[i] - this.stockOffset;

            // Determine color based on direction
            if (this.stockData[i] > this.stockData[i - 1]) {
                // Going down (dip) - RED
                this.ctx.strokeStyle = '#ff0000';
            } else {
                // Going up - GREEN
                this.ctx.strokeStyle = '#00ff00';
            }

            this.ctx.beginPath();
            this.ctx.moveTo(x1, y1);
            this.ctx.lineTo(x2, y2);
            this.ctx.stroke();
        }

        // Draw current value indicator
        const currentValue = (Math.abs(this.stockOffset) / 10).toFixed(2);

        // Value box
        this.ctx.fillStyle = 'rgba(0, 0, 0, 0.8)';
        this.ctx.fillRect(this.canvas.width - 120, 10, 110, 40);

        const isRed = subBassLevel > 0.8;
        this.ctx.fillStyle = isRed ? '#ff0000' : '#00ff00';
        this.ctx.font = 'bold 20px Arial';
        this.ctx.textAlign = 'right';
        this.ctx.fillText(`$${currentValue}`, this.canvas.width - 15, 35);

        // Labels
        this.ctx.fillStyle = '#00aaff';
        this.ctx.font = 'bold 14px Arial';
        this.ctx.textAlign = 'left';
        this.ctx.fillText('📈 TO THE MOON', 10, 25);
        this.ctx.fillStyle = '#ffffff';
        this.ctx.font = '12px Arial';
        this.ctx.fillText('🔴 SUB-BASS = DIP', 10, 45);
        this.ctx.fillText('🟢 MUSIC = UP', 10, 65);
    }

    drawOrangeAmp() {
        // Orange-tinted studio amplifier visualizer
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Amp background (warm orange/brown gradient)
        const bgGradient = this.ctx.createLinearGradient(0, 0, 0, this.canvas.height);
        bgGradient.addColorStop(0, '#1a0f00');
        bgGradient.addColorStop(0.5, '#2a1500');
        bgGradient.addColorStop(1, '#1a0f00');
        this.ctx.fillStyle = bgGradient;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Amp chassis
        const ampWidth = Math.min(this.canvas.width * 0.85, 850);
        const ampHeight = Math.min(this.canvas.height * 0.75, 450);
        const ampX = centerX - ampWidth / 2;
        const ampY = centerY - ampHeight / 2;

        // Amp body (wood grain texture simulation)
        const woodGradient = this.ctx.createLinearGradient(ampX, ampY, ampX, ampY + ampHeight);
        woodGradient.addColorStop(0, '#3a2010');
        woodGradient.addColorStop(0.5, '#2a1508');
        woodGradient.addColorStop(1, '#3a2010');
        this.ctx.fillStyle = woodGradient;
        this.ctx.fillRect(ampX, ampY, ampWidth, ampHeight);

        // Amp border
        this.ctx.strokeStyle = '#1a0a00';
        this.ctx.lineWidth = 4;
        this.ctx.strokeRect(ampX, ampY, ampWidth, ampHeight);

        // Faceplate (brushed metal look)
        const faceWidth = ampWidth - 40;
        const faceHeight = ampHeight - 40;
        const faceX = ampX + 20;
        const faceY = ampY + 20;

        const faceGradient = this.ctx.createLinearGradient(faceX, faceY, faceX, faceY + faceHeight);
        faceGradient.addColorStop(0, '#4a3520');
        faceGradient.addColorStop(0.5, '#3a2510');
        faceGradient.addColorStop(1, '#4a3520');
        this.ctx.fillStyle = faceGradient;
        this.ctx.fillRect(faceX, faceY, faceWidth, faceHeight);

        // VU Meters (classic analog style)
        const meterWidth = faceWidth * 0.4;
        const meterHeight = 100;
        const meterY = faceY + 30;

        // Left VU Meter
        const leftMeterX = faceX + 30;
        this.drawVUMeter(leftMeterX, meterY, meterWidth, meterHeight, 'L');

        // Right VU Meter
        const rightMeterX = faceX + faceWidth - meterWidth - 30;
        this.drawVUMeter(rightMeterX, meterY, meterWidth, meterHeight, 'R');

        // Spectrum display area (orange tinted)
        const spectrumY = meterY + meterHeight + 40;
        const spectrumHeight = faceHeight - meterHeight - 120;
        const spectrumWidth = faceWidth - 60;
        const spectrumX = faceX + 30;

        // Spectrum background
        this.ctx.fillStyle = '#1a0f05';
        this.ctx.fillRect(spectrumX, spectrumY, spectrumWidth, spectrumHeight);

        // Spectrum border
        this.ctx.strokeStyle = '#ff8800';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(spectrumX, spectrumY, spectrumWidth, spectrumHeight);

        // Save context state
        this.ctx.save();

        // Apply pixelated/blurry effect for vintage display look
        this.ctx.imageSmoothingEnabled = false; // Pixelated effect
        this.ctx.filter = 'blur(1.5px)'; // Slight blur for vintage CRT look

        // Draw spectrum bars
        const barCount = 40;
        const barWidth = (spectrumWidth - 20) / barCount;

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * (spectrumHeight - 20) * (this.settings.sensitivity / 5);

            const x = spectrumX + 10 + i * barWidth;
            const y = spectrumY + spectrumHeight - 10 - barHeight;

            // Orange gradient for bars
            const barGradient = this.ctx.createLinearGradient(x, y, x, y + barHeight);
            barGradient.addColorStop(0, '#ff8800');
            barGradient.addColorStop(0.5, '#ff6600');
            barGradient.addColorStop(1, '#cc4400');

            this.ctx.fillStyle = barGradient;
            this.ctx.fillRect(x, y, barWidth - 2, barHeight);

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 10;
                this.ctx.shadowColor = '#ff6600';
                this.ctx.fillRect(x, y, barWidth - 2, barHeight);
                this.ctx.shadowBlur = 0;
            }
        }

        // Add scanline effect for extra vintage feel
        this.ctx.globalAlpha = 0.1;
        this.ctx.fillStyle = '#000000';
        for (let y = spectrumY; y < spectrumY + spectrumHeight; y += 3) {
            this.ctx.fillRect(spectrumX, y, spectrumWidth, 1);
        }

        // Restore context state
        this.ctx.restore();

        // Brand/Model text
        this.ctx.font = 'bold 20px Arial';
        this.ctx.fillStyle = '#ff8800';
        this.ctx.textAlign = 'center';
        this.ctx.shadowBlur = 5;
        this.ctx.shadowColor = '#ff6600';
        this.ctx.fillText('STUDIO AMPLIFIER', centerX, faceY + faceHeight - 15);
        this.ctx.shadowBlur = 0;

        // Control knobs
        const knobY = faceY + faceHeight - 60;
        const knobRadius = 18;
        const knobSpacing = 60;
        const knobStartX = centerX - (knobSpacing * 2);

        const knobLabels = ['GAIN', 'BASS', 'MID', 'TREBLE', 'VOL'];
        for (let i = 0; i < 5; i++) {
            const knobX = knobStartX + i * knobSpacing;

            // Knob body
            this.ctx.beginPath();
            this.ctx.arc(knobX, knobY, knobRadius, 0, Math.PI * 2);
            this.ctx.fillStyle = '#2a1a0a';
            this.ctx.fill();
            this.ctx.strokeStyle = '#ff6600';
            this.ctx.lineWidth = 2;
            this.ctx.stroke();

            // Knob indicator
            const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
            const angle = (average / 255) * Math.PI * 1.5 - Math.PI * 0.75;
            this.ctx.beginPath();
            this.ctx.moveTo(knobX, knobY);
            this.ctx.lineTo(
                knobX + Math.cos(angle) * knobRadius * 0.7,
                knobY + Math.sin(angle) * knobRadius * 0.7
            );
            this.ctx.strokeStyle = '#ff8800';
            this.ctx.lineWidth = 3;
            this.ctx.stroke();

            // Knob label
            this.ctx.font = 'bold 10px Arial';
            this.ctx.fillStyle = '#ff8800';
            this.ctx.textAlign = 'center';
            this.ctx.fillText(knobLabels[i], knobX, knobY + knobRadius + 15);
        }
    }

    drawVUMeter(x, y, width, height, label) {
        // VU meter background
        this.ctx.fillStyle = '#0a0505';
        this.ctx.fillRect(x, y, width, height);

        // VU meter border
        this.ctx.strokeStyle = '#ff6600';
        this.ctx.lineWidth = 2;
        this.ctx.strokeRect(x, y, width, height);

        // Calculate VU level
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const level = (average / 255);

        // Draw VU scale arc
        const centerX = x + width / 2;
        const centerY = y + height - 20;
        const radius = width * 0.4;
        const startAngle = Math.PI * 0.75;
        const endAngle = Math.PI * 0.25;

        // Scale markings
        this.ctx.strokeStyle = '#ff8800';
        this.ctx.lineWidth = 2;
        for (let i = 0; i <= 10; i++) {
            const angle = startAngle + (endAngle - startAngle) * (i / 10);
            const x1 = centerX + Math.cos(angle) * (radius - 10);
            const y1 = centerY + Math.sin(angle) * (radius - 10);
            const x2 = centerX + Math.cos(angle) * radius;
            const y2 = centerY + Math.sin(angle) * radius;

            this.ctx.beginPath();
            this.ctx.moveTo(x1, y1);
            this.ctx.lineTo(x2, y2);
            this.ctx.stroke();
        }

        // Needle
        const needleAngle = startAngle + (endAngle - startAngle) * level;
        this.ctx.beginPath();
        this.ctx.moveTo(centerX, centerY);
        this.ctx.lineTo(
            centerX + Math.cos(needleAngle) * (radius - 5),
            centerY + Math.sin(needleAngle) * (radius - 5)
        );
        this.ctx.strokeStyle = '#ff3300';
        this.ctx.lineWidth = 3;
        this.ctx.shadowBlur = 10;
        this.ctx.shadowColor = '#ff3300';
        this.ctx.stroke();
        this.ctx.shadowBlur = 0;

        // Needle pivot
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, 5, 0, Math.PI * 2);
        this.ctx.fillStyle = '#ff6600';
        this.ctx.fill();

        // Label
        this.ctx.font = 'bold 16px Arial';
        this.ctx.fillStyle = '#ff8800';
        this.ctx.textAlign = 'center';
        this.ctx.fillText(label, centerX, y + 20);
    }

    drawRobot() {
        // Robotic geometric visualizer with moving parts
        const colors = this.colorSchemes[this.settings.colorScheme];
        const centerX = this.canvas.width / 2;
        const centerY = this.canvas.height / 2;

        // Calculate average for movement
        const average = this.dataArray.reduce((a, b) => a + b) / this.dataArray.length;
        const intensity = (average / 255) * (this.settings.sensitivity / 5);

        // Draw rotating geometric shapes
        const time = Date.now() * 0.001;
        const rotation = time + intensity * 2;

        // Outer rotating squares
        for (let i = 0; i < 4; i++) {
            const angle = rotation + (i * Math.PI / 2);
            const distance = 80 + intensity * 40;
            const x = centerX + Math.cos(angle) * distance;
            const y = centerY + Math.sin(angle) * distance;
            const size = 30 + intensity * 20;

            this.ctx.save();
            this.ctx.translate(x, y);
            this.ctx.rotate(rotation * 2);

            this.ctx.strokeStyle = colors[i % colors.length];
            this.ctx.lineWidth = 3;
            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 20;
                this.ctx.shadowColor = colors[i % colors.length];
            }
            this.ctx.strokeRect(-size / 2, -size / 2, size, size);

            this.ctx.restore();
        }

        // Center pulsing circle
        this.ctx.beginPath();
        this.ctx.arc(centerX, centerY, 40 + intensity * 30, 0, Math.PI * 2);
        this.ctx.strokeStyle = colors[0];
        this.ctx.lineWidth = 4;
        this.ctx.stroke();

        // Frequency bars in circle
        const barCount = 32;
        const radius = 60;
        const angleStep = (Math.PI * 2) / barCount;

        for (let i = 0; i < barCount; i++) {
            const dataIndex = Math.floor(i * this.dataArray.length / barCount);
            const barHeight = (this.dataArray[dataIndex] / 255) * 60 * (this.settings.sensitivity / 5);

            const angle = i * angleStep;
            const x1 = centerX + Math.cos(angle) * radius;
            const y1 = centerY + Math.sin(angle) * radius;
            const x2 = centerX + Math.cos(angle) * (radius + barHeight);
            const y2 = centerY + Math.sin(angle) * (radius + barHeight);

            const colorIndex = Math.floor((i / barCount) * colors.length);
            const color = colors[colorIndex % colors.length];

            this.ctx.strokeStyle = color;
            this.ctx.lineWidth = 3;

            this.ctx.beginPath();
            this.ctx.moveTo(x1, y1);
            this.ctx.lineTo(x2, y2);
            this.ctx.stroke();
        }

        // Corner indicators
        const cornerSize = 20 + intensity * 10;
        const corners = [
            [20, 20],
            [this.canvas.width - 20, 20],
            [20, this.canvas.height - 20],
            [this.canvas.width - 20, this.canvas.height - 20]
        ];

        corners.forEach((corner, idx) => {
            this.ctx.strokeStyle = colors[idx % colors.length];
            this.ctx.lineWidth = 2;
            this.ctx.strokeRect(corner[0] - cornerSize / 2, corner[1] - cornerSize / 2, cornerSize, cornerSize);
            this.ctx.shadowBlur = 0;

            const time = Date.now() * 0.001;
            const halfWidth = this.canvas.width / 2;

            // Left channel - water ripples
            for (let i = 0; i < 50; i++) {
                const dataIndex = Math.floor(i * (this.dataArray.length / 2) / 50);
                const amplitude = (this.dataArray[dataIndex] / 255) * (this.settings.sensitivity / 5);

                const y = (i / 50) * this.canvas.height;
                const rippleCount = 8;

                this.ctx.strokeStyle = colors[i % colors.length];
                this.ctx.lineWidth = 2;
                this.ctx.globalAlpha = 0.3 + amplitude * 0.7;

                if (this.settings.glowEffect) {
                    this.ctx.shadowBlur = 10;
                    this.ctx.shadowColor = colors[i % colors.length];
                }

                this.ctx.beginPath();
                for (let x = 0; x < halfWidth; x += 5) {
                    const wave = Math.sin((x / 30) + time * 2 + i * 0.5) * amplitude * 20;
                    const ripple = Math.sin((x / 15) + time * 3) * amplitude * 10;
                    if (x === 0) {
                        this.ctx.moveTo(x, y + wave + ripple);
                    } else {
                        this.ctx.lineTo(x, y + wave + ripple);
                    }
                }
                this.ctx.stroke();
            }

            // Right channel - water ripples
            for (let i = 0; i < 50; i++) {
                const dataIndex = Math.floor((this.dataArray.length / 2) + i * (this.dataArray.length / 2) / 50);
                const amplitude = (this.dataArray[dataIndex] / 255) * (this.settings.sensitivity / 5);

                const y = (i / 50) * this.canvas.height;

                this.ctx.strokeStyle = colors[i % colors.length];
                this.ctx.lineWidth = 2;
                this.ctx.globalAlpha = 0.3 + amplitude * 0.7;

                if (this.settings.glowEffect) {
                    this.ctx.shadowBlur = 10;
                    this.ctx.shadowColor = colors[i % colors.length];
                }

                this.ctx.beginPath();
                for (let x = halfWidth; x < this.canvas.width; x += 5) {
                    const wave = Math.sin((x / 30) + time * 2 + i * 0.5) * amplitude * 20;
                    const ripple = Math.sin((x / 15) + time * 3) * amplitude * 10;
                    if (x === halfWidth) {
                        this.ctx.moveTo(x, y + wave + ripple);
                    } else {
                        this.ctx.lineTo(x, y + wave + ripple);
                    }
                }
                this.ctx.stroke();
            }

            this.ctx.shadowBlur = 0;
            this.ctx.globalAlpha = 1.0;
        });
    }

    drawWaves() {
        // Ocean waves with L/R channels
        const colors = this.colorSchemes[this.settings.colorScheme];
        const halfWidth = this.canvas.width / 2;
        const time = Date.now() * 0.001;

        // Ocean gradient background
        const bgGradient = this.ctx.createLinearGradient(0, 0, 0, this.canvas.height);
        bgGradient.addColorStop(0, '#0a1929');
        bgGradient.addColorStop(0.5, '#1a3a52');
        bgGradient.addColorStop(1, '#0a1929');
        this.ctx.fillStyle = bgGradient;
        this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

        // Draw divider
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        this.ctx.lineWidth = 3;
        this.ctx.setLineDash([10, 5]);
        this.ctx.beginPath();
        this.ctx.moveTo(halfWidth, 0);
        this.ctx.lineTo(halfWidth, this.canvas.height);
        this.ctx.stroke();
        this.ctx.setLineDash([]);

        // Labels
        this.ctx.font = 'bold 24px Orbitron';
        this.ctx.fillStyle = colors[0];
        this.ctx.textAlign = 'center';
        this.ctx.shadowBlur = 15;
        this.ctx.shadowColor = colors[0];
        this.ctx.fillText('LEFT', halfWidth / 2, 35);
        this.ctx.fillText('RIGHT', halfWidth + halfWidth / 2, 35);
        this.ctx.shadowBlur = 0;

        // Left channel - flowing waves
        const leftBarCount = 30;
        for (let i = 0; i < leftBarCount; i++) {
            const dataIndex = Math.floor(i * (this.dataArray.length / 2) / leftBarCount);
            const amplitude = (this.dataArray[dataIndex] / 255) * (this.settings.sensitivity / 5);

            const x = (i / leftBarCount) * halfWidth;
            const waveHeight = amplitude * this.canvas.height * 0.8;

            const gradient = this.ctx.createLinearGradient(x, this.canvas.height, x, this.canvas.height - waveHeight);
            gradient.addColorStop(0, colors[0]);
            gradient.addColorStop(0.5, colors[1]);
            gradient.addColorStop(1, colors[2]);

            this.ctx.fillStyle = gradient;
            this.ctx.globalAlpha = 0.6 + amplitude * 0.4;

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 20;
                this.ctx.shadowColor = colors[i % colors.length];
            }

            // Draw wave shape
            this.ctx.beginPath();
            const barWidth = halfWidth / leftBarCount;
            const waveOffset = Math.sin(time * 2 + i * 0.3) * 15;

            this.ctx.moveTo(x, this.canvas.height);
            this.ctx.lineTo(x, this.canvas.height - waveHeight + waveOffset);
            this.ctx.quadraticCurveTo(
                x + barWidth / 2,
                this.canvas.height - waveHeight + waveOffset - 10,
                x + barWidth,
                this.canvas.height - waveHeight + waveOffset
            );
            this.ctx.lineTo(x + barWidth, this.canvas.height);
            this.ctx.closePath();
            this.ctx.fill();
        }

        // Right channel - flowing waves
        const rightBarCount = 30;
        for (let i = 0; i < rightBarCount; i++) {
            const dataIndex = Math.floor((this.dataArray.length / 2) + i * (this.dataArray.length / 2) / rightBarCount);
            const amplitude = (this.dataArray[dataIndex] / 255) * (this.settings.sensitivity / 5);

            const x = halfWidth + (i / rightBarCount) * halfWidth;
            const waveHeight = amplitude * this.canvas.height * 0.8;

            const gradient = this.ctx.createLinearGradient(x, this.canvas.height, x, this.canvas.height - waveHeight);
            gradient.addColorStop(0, colors[2]);
            gradient.addColorStop(0.5, colors[1]);
            gradient.addColorStop(1, colors[0]);

            this.ctx.fillStyle = gradient;
            this.ctx.globalAlpha = 0.6 + amplitude * 0.4;

            if (this.settings.glowEffect) {
                this.ctx.shadowBlur = 20;
                this.ctx.shadowColor = colors[i % colors.length];
            }

            // Draw wave shape
            this.ctx.beginPath();
            const barWidth = halfWidth / rightBarCount;
            const waveOffset = Math.sin(time * 2 + i * 0.3) * 15;

            this.ctx.moveTo(x, this.canvas.height);
            this.ctx.lineTo(x, this.canvas.height - waveHeight + waveOffset);
            this.ctx.quadraticCurveTo(
                x + barWidth / 2,
                this.canvas.height - waveHeight + waveOffset - 10,
                x + barWidth,
                this.canvas.height - waveHeight + waveOffset
            );
            this.ctx.lineTo(x + barWidth, this.canvas.height);
            this.ctx.closePath();
            this.ctx.fill();
        }

        this.ctx.shadowBlur = 0;
        this.ctx.globalAlpha = 1.0;
    }
}


// UI Functions
function updateStatus(text, state = '') {
    const statusText = document.getElementById('statusText');
    statusText.textContent = text;
    statusText.className = 'value ' + state;
}

function updateMode(text) {
    const modeText = document.getElementById('currentMode');
    modeText.textContent = text;
}

// Initialize
var visualizer = null;

document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('visualizer');
    visualizer = new RetroVisualizer(canvas);

    // Open Visualizer Tab button
    const openVisualizerBtn = document.getElementById('openVisualizerBtn');
    if (openVisualizerBtn) {
        openVisualizerBtn.addEventListener('click', () => {
            chrome.windows.create({
                url: chrome.runtime.getURL('visualizer-page.html'),
                type: 'popup',
                width: 1200,
                height: 800
            });
        });
    }

    // Buttons
    const startBtn = document.getElementById('startBtn');
    const stopBtn = document.getElementById('stopBtn');
    const modeBtn = document.getElementById('modeBtn');

    startBtn.addEventListener('click', async () => {
        const success = await visualizer.start();
        if (success) {
            startBtn.style.display = 'none';
            stopBtn.style.display = 'flex';
        }
    });

    stopBtn.addEventListener('click', () => {
        visualizer.stop();
        startBtn.style.display = 'flex';
        stopBtn.style.display = 'none';
    });

    modeBtn.addEventListener('click', () => {
        visualizer.cycleMode();
    });

    // Settings
    const settingsToggle = document.getElementById('settingsToggle');
    const settingsPanel = document.getElementById('settingsPanel');

    settingsToggle.addEventListener('click', () => {
        settingsPanel.classList.toggle('open');
        settingsToggle.classList.toggle('active');
    });

    // Color scheme
    document.getElementById('colorScheme').addEventListener('change', (e) => {
        visualizer.updateSettings({ colorScheme: e.target.value });
    });

    // Sensitivity
    const sensitivitySlider = document.getElementById('sensitivity');
    const sensitivityValue = sensitivitySlider.nextElementSibling;
    sensitivitySlider.addEventListener('input', (e) => {
        const value = parseInt(e.target.value);
        visualizer.updateSettings({ sensitivity: value });
        sensitivityValue.textContent = value;
    });

    // Smoothing
    const smoothingSlider = document.getElementById('smoothing');
    const smoothingValue = smoothingSlider.nextElementSibling;
    smoothingSlider.addEventListener('input', (e) => {
        const value = parseInt(e.target.value);
        visualizer.updateSettings({ smoothing: value });
        smoothingValue.textContent = value + '%';
    });

    // Bar count
    const barCountSlider = document.getElementById('barCount');
    const barCountValue = barCountSlider.nextElementSibling;
    barCountSlider.addEventListener('input', (e) => {
        const value = parseInt(e.target.value);
        visualizer.updateSettings({ barCount: value });
        barCountValue.textContent = value;
    });

    // Mirror mode
    document.getElementById('mirrorMode').addEventListener('change', (e) => {
        visualizer.updateSettings({ mirrorMode: e.target.checked });
    });

    // Glow effect
    document.getElementById('glowEffect').addEventListener('change', (e) => {
        visualizer.updateSettings({ glowEffect: e.target.checked });
    });

    // Reset
    document.getElementById('resetSettings').addEventListener('click', () => {
        visualizer.settings = {
            colorScheme: 'neon',
            sensitivity: 5,
            smoothing: 80,
            barCount: 64,
            mirrorMode: false,
            glowEffect: true
        };

        document.getElementById('colorScheme').value = 'neon';
        sensitivitySlider.value = 5;
        sensitivityValue.textContent = '5';
        smoothingSlider.value = 80;
        smoothingValue.textContent = '80%';
        barCountSlider.value = 64;
        barCountValue.textContent = '64';
        document.getElementById('mirrorMode').checked = false;
        document.getElementById('glowEffect').checked = true;

        visualizer.saveSettings();
    });
});
