# 🎵 Retro Audio Visualizer 2000

Experience the nostalgia of Y2K-era audio visualization! This Chrome extension brings back the classic vibes of Windows Media Player and Winamp with modern audio capture technology.

## ✨ Features

## 🎵 How to Use

**IMPORTANT:** The visualizer captures audio from browser tabs, so you need to have audio playing first!

1. **Open a tab with audio** (YouTube, Spotify, SoundCloud, etc.)
2. **Start playing music/audio**
3. **Click the Retro Visualizer extension icon**
4. **Click "OPEN VISUALIZER TAB"** - A popup window will open
5. **Click "START"** to begin visualizing
6. **Click "NEXT MODE"** to cycle through visualizer modes
7. **Click "SETTINGS"** (⚙) to customize colors, sensitivity, etc.

### 🎨 Visualizer Modes

The extension includes **12 stunning visualizer modes**:

1. **SPECTRUM** - Classic frequency bars
2. **WAVEFORM** - Smooth oscillating wave
3. **CIRCULAR** - 360° radial spectrum
4. **VHS** - Authentic VHS tape effect with glitches
5. **OSCILLOSCOPE** - Retro grid-based waveform
6. **BARS 3D** - Pseudo-3D spectrum bars
7. **CAR RADIO** ⭐ - Classic car stereo with orange LCD display
8. **VFD** ⭐ - Vacuum fluorescent display with blue-green glow
9. **ORANGE AMP** ⭐ - Studio amplifier with VU meters and vintage pixelated display
10. **HEART RATE** ⭐ - ECG/medical monitor style with BPM counter
11. **ROBOT** - Geometric visualizer with moving parts
12. **WAVES** - Ocean waves with L/R channels

### ⚙️ Settings

Customize your experience:
- **Color Schemes**: Neon Dreams, Plasma Wave, Matrix Green, Sunset Blvd, Ocean Deep, Fire & Ice
- **Sensitivity**: Adjust how reactive the visualizer is (1-10)
- **Smoothing**: Control animation smoothness (0-100%)
- **Bar Count**: Number of frequency bars (16-128)
- **Mirror Mode**: Enable vertical mirroring
- **Glow Effect**: Toggle glow effects on/off

### 🎬 VHS Effect Details

The VHS mode includes authentic retro effects:
- RGB channel separation (chromatic aberration)
- Random horizontal glitches
- Scan line overlay
- VHS tracking distortion
- Film grain noise
- Authentic 2000s aesthetic

## 🚀 Installation

1. Navigate to `/Users/syed-atif/.gemini/antigravity/scratch/retro-visualizer-2000s`
2. Open Chrome → `chrome://extensions/`
3. Enable "Developer mode"
4. Click "Load unpacked"
5. Select the `retro-visualizer-2000s` folder
6. Rock out to Y2K vibes! 🎸

## 🎮 Usage

1. Play audio in any browser tab
2. Click the Retro Visualizer extension icon
3. Click **START** to begin visualization
4. Click **MODE** to cycle through visualization styles
5. Open **SETTINGS** to customize appearance
6. Enjoy the nostalgia! 🕹️

## 🎯 Tips

- Try VHS mode with electronic music for maximum retro vibes
- Use Circular mode for a hypnotic experience
- Adjust sensitivity based on your audio volume
- Enable Mirror Mode for symmetrical visuals
- Experiment with different color schemes

## 🔧 Technical Details

- Uses Chrome Tab Capture API
- Web Audio API for real-time analysis
- Canvas-based rendering at 60fps
- Audio plays normally while visualizing
- Settings saved automatically

## 🎨 Aesthetic

Inspired by:
- Windows Media Player visualizations
- Winamp plugins
- Early 2000s digital aesthetics
- VHS tape artifacts
- Neon signage and CRT displays

## 📝 License

MIT License - Relive the Y2K era!

---

**~ Bringing back the 2000s, one visualization at a time ~**
